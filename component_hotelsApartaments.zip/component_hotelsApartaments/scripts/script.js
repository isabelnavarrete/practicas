$(function () {
        $(".option_list .option_element").on("click", function() {
            $(this).closest(".option_list").find(".active").removeClass("active");
            $(this).addClass("active");

            var filters_actives = $(".horizontal_bar2 .option_element.active"),
                num_actives = filters_actives.length;

            $(".container_pictures .container_wrapper").each(function(index, element) {
                console.log($(this));
                var component = $(this),
                    filters_founded = 0;
                $.each(filters_actives, function() {
                    var filter_selected = $(this).data("filter");
                    if(component.hasClass(filter_selected) || filter_selected === "all") {
                        filters_founded++;
                    } else {
                        component.fadeOut();
                        component.removeClass("active");
                    }
                });

                if(filters_founded === num_actives) {
                    component.fadeIn();
                    component.addClass("active");
                }
            });

            update_num_hotels();
        });
    });

    function update_num_hotels() {
        var num_actives = $(".container_pictures .container_wrapper.active").length;

        $(".num_hotels").text(num_actives);

        if(num_actives === 1) {
            $(".tag_hotels").text("hotel");
        } else {
            $(".tag_hotels").text("hoteles");
        }
    }
       /* $(document).ready(function () {
        $('.button .icon').click(function (){
            $(".option_list").fadeToggle('fast');
        });
    });*/
    $(function () {
        $(".button .icon").on("click", function () {
            $(this).closest(".button").find(".option_list").fadeToggle();
            $(this).addClass("toggle");
        });
    });